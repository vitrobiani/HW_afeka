The Makefile will create executables ending with the suffix .exe, keep that in mind when activating the loopcmp executable. <b/>

```
./loopcmp.exe ./lencmp.exe
or
./loopcmp.exe lencmp.exe
or
./loopcmp.exe /path/to/lencmp.exe

```
